package Assignment2;

//There are 5 of each type
public enum ApparatusType {
	LEGPRESSMACHINE, BARBELL, HACKSQUATMACHINE, LEGEXTENSIONMACHINE, 
	LEGCURLMACHINE, LATPULLDOWNMACHINE, PECKDECKMACHINE,
	CABLECROSSOVER
}

// TODO: Possibly create methods to generate a random apparatus type