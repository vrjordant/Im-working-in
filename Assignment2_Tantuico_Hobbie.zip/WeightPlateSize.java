package Assignment2;

//How does this work?
// 75 of 10kg, 90 of 5kg, 110 of 3kg
// Recorded in noOfWeightPlates
public enum WeightPlateSize {
	SMALL_3KG, MEDIUM_5KG, LARGE_10KG
}

// TODO: Possibly create methods to generate a random weight plate size
